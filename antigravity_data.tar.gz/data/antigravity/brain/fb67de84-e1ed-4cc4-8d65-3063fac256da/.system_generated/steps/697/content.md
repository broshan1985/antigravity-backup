Title: Live Content

Description: Fetched live

Source: https://raw.githubusercontent.com/MetaCubeX/mihomo/Alpha/component/fakeip/skipper.go

---

package fakeip

import (
	C "github.com/metacubex/mihomo/constant"
)

const (
	UseFakeIP = "fake-ip"
	UseRealIP = "real-ip"
)

type Skipper struct {
	Rules []C.Rule
	Host  []C.DomainMatcher
	Mode  C.FilterMode
}

// ShouldSkipped return if domain should be skipped
func (p *Skipper) ShouldSkipped(domain string) bool {
	if len(p.Rules) > 0 {
		metadata := &C.Metadata{Host: domain}
		for _, rule := range p.Rules {
			if matched, act

